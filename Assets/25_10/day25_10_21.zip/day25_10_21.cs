using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class day25_10_21 : MonoBehaviour
{
    void PrintHelloWorld()
    {
        Debug.Log("Hello world");
    }

    int Sum(int inputA, int inputB)
    {
        int result = 0;
        result = inputA + inputB;
        return result;
    }

    float Division(float inputA, float inputB)
    {
        float result = 0;
        if(inputA==0) //������=0
        {
            Debug.Log("Error: 0 Divide!!!");
            return -1;
        }
        else if (inputB == 0) //����=0
        {
            Debug.Log("Error: Divide by 0!!!");
            return -1;
        }
            result = inputA / inputB;
        return result;
    }

    //�⺻ ������ ���� ����(�⺻ ������ = ���ݷ�*��� / 1000)
    int BaseDamage(float ATK, float CoefDamage) 
    {
        float result = 0;
        if(ATK==0 || CoefDamage == 0)
        {
            Debug.Log("Error: Divide 0!!");
            return -1;
        }
        result = (ATK * CoefDamage) / 1000;
        return (int)result;
    }
    // Start is called before the first frame update
    void Start()
    {
        PrintHelloWorld();
        int sum = Sum(5, 7);
        Debug.Log(sum);
        float div1 = Division(12f, 7f);
        if (div1 != -1)  Debug.Log(div1);
        float div2 = Division(12f, 0f);
        if (div2 != -1) Debug.Log(div2);
        float div3 = Division(0f, 12f);
        if (div3 != -1) Debug.Log(div3);
        int BD1 = BaseDamage(17500f, 2.3f);
        if (BD1 != -1) Debug.Log(BD1);
        int BD2 = BaseDamage(2333112f, 0f);
        if (BD2 != -1) Debug.Log(BD2);
    }
}
